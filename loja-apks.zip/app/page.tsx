"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Download, Search, Star, Shield, LogIn } from "lucide-react"
import Link from "next/link"

interface App {
  id: string
  name: string
  description: string
  version: string
  size: string
  rating: number
  downloads: string
  category: string
  icon: string
  downloadUrl: string
  screenshots: string[]
}

export default function HomePage() {
  const [apps, setApps] = useState<App[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  useEffect(() => {
    // Carregar apps do localStorage
    const savedApps = localStorage.getItem("modsPlayApps")
    if (savedApps) {
      setApps(JSON.parse(savedApps))
    } else {
      // Apps de exemplo
      const defaultApps: App[] = [
        {
          id: "1",
          name: "WhatsApp Plus",
          description: "WhatsApp modificado com recursos extras como temas personalizados e privacidade avançada",
          version: "2.23.25.84",
          size: "65 MB",
          rating: 4.5,
          downloads: "10M+",
          category: "Social",
          icon: "/placeholder.svg?height=80&width=80",
          downloadUrl: "#",
          screenshots: ["/placeholder.svg?height=400&width=200"],
        },
        {
          id: "2",
          name: "Instagram Pro",
          description: "Instagram com download de fotos/vídeos e recursos de privacidade",
          version: "295.0.0.31.111",
          size: "45 MB",
          rating: 4.3,
          downloads: "5M+",
          category: "Social",
          icon: "/placeholder.svg?height=80&width=80",
          downloadUrl: "#",
          screenshots: ["/placeholder.svg?height=400&width=200"],
        },
        {
          id: "3",
          name: "YouTube Vanced",
          description: "YouTube sem anúncios com reprodução em segundo plano",
          version: "17.03.38",
          size: "78 MB",
          rating: 4.8,
          downloads: "50M+",
          category: "Mídia",
          icon: "/placeholder.svg?height=80&width=80",
          downloadUrl: "#",
          screenshots: ["/placeholder.svg?height=400&width=200"],
        },
      ]
      setApps(defaultApps)
      localStorage.setItem("modsPlayApps", JSON.stringify(defaultApps))
    }
  }, [])

  const categories = ["all", "Social", "Mídia", "Jogos", "Produtividade", "Ferramentas"]

  const filteredApps = apps.filter((app) => {
    const matchesSearch =
      app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || app.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleDownload = (app: App) => {
    // Simular download - em uma implementação real, isso faria o download do arquivo
    const link = document.createElement("a")
    link.href = app.downloadUrl
    link.download = `${app.name.replace(/\s+/g, "_")}_v${app.version}.apk`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    // Mostrar notificação de download
    alert(`Download iniciado: ${app.name} v${app.version}`)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-8 w-8 text-primary" />
            <h1 className="text-2xl font-bold text-primary">Mods Play</h1>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative w-96 max-w-sm">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Buscar apps modificados..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Link href="/admin/login">
              <Button variant="outline" size="sm">
                <LogIn className="h-4 w-4 mr-2" />
                Admin
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="container py-6">
        {/* Categories */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="whitespace-nowrap"
            >
              {category === "all" ? "Todos" : category}
            </Button>
          ))}
        </div>

        {/* Apps Grid */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredApps.map((app) => (
            <Card key={app.id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16 rounded-lg">
                    <AvatarImage src={app.icon || "/placeholder.svg"} alt={app.name} />
                    <AvatarFallback className="rounded-lg">{app.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1">
                    <CardTitle className="text-lg">{app.name}</CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">{app.category}</Badge>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm text-muted-foreground">{app.rating}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <CardDescription className="line-clamp-2">{app.description}</CardDescription>

                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>v{app.version}</span>
                  <span>{app.size}</span>
                  <span>{app.downloads}</span>
                </div>

                <Button onClick={() => handleDownload(app)} className="w-full" size="lg">
                  <Download className="h-4 w-4 mr-2" />
                  Download APK
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredApps.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Nenhum app encontrado com os filtros aplicados.</p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/50 mt-12">
        <div className="container py-8">
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center gap-2">
              <Shield className="h-6 w-6 text-primary" />
              <span className="text-lg font-semibold">Mods Play</span>
            </div>
            <p className="text-sm text-muted-foreground">Sua loja de apps modificados confiável</p>
            <p className="text-xs text-muted-foreground">⚠️ Use apps modificados por sua própria conta e risco</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
