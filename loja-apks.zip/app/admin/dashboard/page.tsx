"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Shield, Plus, Edit, Trash2, LogOut, Download, Star, Package } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import Link from "next/link"

interface App {
  id: string
  name: string
  description: string
  version: string
  size: string
  rating: number
  downloads: string
  category: string
  icon: string
  downloadUrl: string
  screenshots: string[]
}

export default function AdminDashboard() {
  const [apps, setApps] = useState<App[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingApp, setEditingApp] = useState<App | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    version: "",
    size: "",
    rating: 0,
    downloads: "",
    category: "",
    icon: "",
    downloadUrl: "",
  })
  const router = useRouter()

  useEffect(() => {
    // Verificar se está logado
    const isAdmin = localStorage.getItem("modsPlayAdmin")
    if (!isAdmin) {
      router.push("/admin/login")
      return
    }

    // Carregar apps
    const savedApps = localStorage.getItem("modsPlayApps")
    if (savedApps) {
      setApps(JSON.parse(savedApps))
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("modsPlayAdmin")
    router.push("/")
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      version: "",
      size: "",
      rating: 0,
      downloads: "",
      category: "",
      icon: "",
      downloadUrl: "",
    })
    setEditingApp(null)
  }

  const handleAddApp = () => {
    const newApp: App = {
      id: Date.now().toString(),
      ...formData,
      screenshots: ["/placeholder.svg?height=400&width=200"],
    }

    const updatedApps = [...apps, newApp]
    setApps(updatedApps)
    localStorage.setItem("modsPlayApps", JSON.stringify(updatedApps))

    setIsAddDialogOpen(false)
    resetForm()
  }

  const handleEditApp = () => {
    if (!editingApp) return

    const updatedApps = apps.map((app) => (app.id === editingApp.id ? { ...app, ...formData } : app))

    setApps(updatedApps)
    localStorage.setItem("modsPlayApps", JSON.stringify(updatedApps))

    setEditingApp(null)
    resetForm()
  }

  const handleDeleteApp = (id: string) => {
    if (confirm("Tem certeza que deseja excluir este app?")) {
      const updatedApps = apps.filter((app) => app.id !== id)
      setApps(updatedApps)
      localStorage.setItem("modsPlayApps", JSON.stringify(updatedApps))
    }
  }

  const startEdit = (app: App) => {
    setEditingApp(app)
    setFormData({
      name: app.name,
      description: app.description,
      version: app.version,
      size: app.size,
      rating: app.rating,
      downloads: app.downloads,
      category: app.category,
      icon: app.icon,
      downloadUrl: app.downloadUrl,
    })
  }

  const categories = ["Social", "Mídia", "Jogos", "Produtividade", "Ferramentas"]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Link href="/" className="flex items-center gap-2">
              <Shield className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-primary">Mods Play</h1>
            </Link>
            <Badge variant="secondary">Admin</Badge>
          </div>

          <div className="flex items-center gap-4">
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={resetForm}>
                  <Plus className="h-4 w-4 mr-2" />
                  Adicionar App
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Adicionar Novo App</DialogTitle>
                  <DialogDescription>Preencha as informações do app modificado</DialogDescription>
                </DialogHeader>

                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nome do App</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="Ex: WhatsApp Plus"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="version">Versão</Label>
                      <Input
                        id="version"
                        value={formData.version}
                        onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                        placeholder="Ex: 2.23.25.84"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Descreva as funcionalidades do app modificado"
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="category">Categoria</Label>
                      <Select
                        value={formData.category}
                        onValueChange={(value) => setFormData({ ...formData, category: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Selecione" />
                        </SelectTrigger>
                        <SelectContent>
                          {categories.map((cat) => (
                            <SelectItem key={cat} value={cat}>
                              {cat}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="size">Tamanho</Label>
                      <Input
                        id="size"
                        value={formData.size}
                        onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                        placeholder="Ex: 65 MB"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="downloads">Downloads</Label>
                      <Input
                        id="downloads"
                        value={formData.downloads}
                        onChange={(e) => setFormData({ ...formData, downloads: e.target.value })}
                        placeholder="Ex: 10M+"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="rating">Avaliação (0-5)</Label>
                      <Input
                        id="rating"
                        type="number"
                        min="0"
                        max="5"
                        step="0.1"
                        value={formData.rating}
                        onChange={(e) => setFormData({ ...formData, rating: Number.parseFloat(e.target.value) })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="icon">URL do Ícone</Label>
                      <Input
                        id="icon"
                        value={formData.icon}
                        onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                        placeholder="URL da imagem do ícone"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="downloadUrl">URL de Download</Label>
                    <Input
                      id="downloadUrl"
                      value={formData.downloadUrl}
                      onChange={(e) => setFormData({ ...formData, downloadUrl: e.target.value })}
                      placeholder="URL do arquivo APK"
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                    Cancelar
                  </Button>
                  <Button onClick={handleAddApp}>Adicionar App</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="container py-6">
        <div className="space-y-6">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Dashboard Administrativo</h2>
            <p className="text-muted-foreground">Gerencie os apps da sua loja Mods Play</p>
          </div>

          {/* Stats */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total de Apps</CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{apps.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Downloads Totais</CardTitle>
                <Download className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {apps.reduce((total, app) => {
                    const downloads = app.downloads.replace(/[^\d]/g, "")
                    return total + Number.parseInt(downloads || "0")
                  }, 0)}
                  M+
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avaliação Média</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {apps.length > 0 ? (apps.reduce((sum, app) => sum + app.rating, 0) / apps.length).toFixed(1) : "0.0"}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Apps List */}
          <Card>
            <CardHeader>
              <CardTitle>Apps Cadastrados</CardTitle>
              <CardDescription>Lista de todos os apps modificados na loja</CardDescription>
            </CardHeader>
            <CardContent>
              {apps.length === 0 ? (
                <div className="text-center py-8">
                  <Package className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">Nenhum app cadastrado ainda</p>
                  <p className="text-sm text-muted-foreground">Clique em "Adicionar App" para começar</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {apps.map((app) => (
                    <div key={app.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <Avatar className="h-16 w-16 rounded-lg">
                        <AvatarImage src={app.icon || "/placeholder.svg"} alt={app.name} />
                        <AvatarFallback className="rounded-lg">{app.name.charAt(0)}</AvatarFallback>
                      </Avatar>

                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">{app.name}</h3>
                          <Badge variant="secondary">{app.category}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground line-clamp-1">{app.description}</p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <span>v{app.version}</span>
                          <span>{app.size}</span>
                          <span>{app.downloads}</span>
                          <div className="flex items-center gap-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span>{app.rating}</span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => startEdit(app)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>Editar App</DialogTitle>
                              <DialogDescription>Edite as informações do app</DialogDescription>
                            </DialogHeader>

                            <div className="grid gap-4 py-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <Label htmlFor="edit-name">Nome do App</Label>
                                  <Input
                                    id="edit-name"
                                    value={formData.name}
                                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-version">Versão</Label>
                                  <Input
                                    id="edit-version"
                                    value={formData.version}
                                    onChange={(e) => setFormData({ ...formData, version: e.target.value })}
                                  />
                                </div>
                              </div>

                              <div className="space-y-2">
                                <Label htmlFor="edit-description">Descrição</Label>
                                <Textarea
                                  id="edit-description"
                                  value={formData.description}
                                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                                  rows={3}
                                />
                              </div>

                              <div className="grid grid-cols-3 gap-4">
                                <div className="space-y-2">
                                  <Label htmlFor="edit-category">Categoria</Label>
                                  <Select
                                    value={formData.category}
                                    onValueChange={(value) => setFormData({ ...formData, category: value })}
                                  >
                                    <SelectTrigger>
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {categories.map((cat) => (
                                        <SelectItem key={cat} value={cat}>
                                          {cat}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-size">Tamanho</Label>
                                  <Input
                                    id="edit-size"
                                    value={formData.size}
                                    onChange={(e) => setFormData({ ...formData, size: e.target.value })}
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-downloads">Downloads</Label>
                                  <Input
                                    id="edit-downloads"
                                    value={formData.downloads}
                                    onChange={(e) => setFormData({ ...formData, downloads: e.target.value })}
                                  />
                                </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                <div className="space-y-2">
                                  <Label htmlFor="edit-rating">Avaliação</Label>
                                  <Input
                                    id="edit-rating"
                                    type="number"
                                    min="0"
                                    max="5"
                                    step="0.1"
                                    value={formData.rating}
                                    onChange={(e) =>
                                      setFormData({ ...formData, rating: Number.parseFloat(e.target.value) })
                                    }
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="edit-icon">URL do Ícone</Label>
                                  <Input
                                    id="edit-icon"
                                    value={formData.icon}
                                    onChange={(e) => setFormData({ ...formData, icon: e.target.value })}
                                  />
                                </div>
                              </div>

                              <div className="space-y-2">
                                <Label htmlFor="edit-downloadUrl">URL de Download</Label>
                                <Input
                                  id="edit-downloadUrl"
                                  value={formData.downloadUrl}
                                  onChange={(e) => setFormData({ ...formData, downloadUrl: e.target.value })}
                                />
                              </div>
                            </div>

                            <DialogFooter>
                              <Button variant="outline" onClick={() => setEditingApp(null)}>
                                Cancelar
                              </Button>
                              <Button onClick={handleEditApp}>Salvar Alterações</Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>

                        <Button variant="outline" size="sm" onClick={() => handleDeleteApp(app.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
